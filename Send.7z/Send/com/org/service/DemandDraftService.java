package com.org.service;

import com.org.DAO.DemandDraftDao;
import com.org.model.DemandDraft;

public class DemandDraftService implements IDemanddraftService{
	
	DemandDraftDao dd_dao=new DemandDraftDao();

	@Override
	public boolean isvalidname(String str) {
		return str.matches("[a-zA-Z]{3,}");	}

	@Override
	public boolean isvalidnumber(String str) {
		return str.matches("\\d{10}");

	}

	@Override
	public boolean isValidDate(String str) {
		return str.matches("[0,1,2,3]\\d{1}-[0,1]\\d{1}-(18|19|20)\\d{2}");
	}

	public int add_demanddraft_details(DemandDraft dddraft) {
		
		return dd_dao.add_demanddraft_details(dddraft);
		
	}
	
	public void getDemandDraftDetails(int a)
	{
		dd_dao.getDemandDraftDetails(a);
	}
	
}
