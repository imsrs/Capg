package com.org.service;

public interface IDemanddraftService {

	public boolean isvalidname(String str);
	public boolean isvalidnumber(String str);
	public boolean 	isValidDate(String str);

}
