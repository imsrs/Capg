package com.org.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.mysql.jdbc.PreparedStatement;
import com.org.model.DemandDraft;

public class DemandDraftDao implements IDemandDraftsDao {
	
	static final Logger logger=Logger.getLogger(DemandDraftDao.class);


	public int add_demanddraft_details(DemandDraft dddraft) {
		
		int temp = 0;
		
		try(Connection conn=getDbConnection())
		{
			String sql="insert into demand_draft(customer_Name,in_Favour_Of,phone_number,date_of_transaction,dd_amount,dd_commission,dd_description)"
					  +"values (?,?,?,?,?,?,?)";
		     java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		     pst.setString(1, dddraft.getCustomer_Name());
		     pst.setString(2, dddraft.getIn_Favour_Of());
		     pst.setString(3, dddraft.getPhone_number());
		     
		     Date date = Date.valueOf(dddraft.getDate_of_transaction());
             pst.setDate(4, date);
             pst.setDouble(5, dddraft.getDd_amount());
		     pst.setInt(6, dddraft.getDd_commission());
		     pst.setString(7, dddraft.getDd_description());

			 int count=pst.executeUpdate();
			
			 if(count>0)
			 {
				 String str="select max(transaction_Id) from demand_draft";
				 java.sql.PreparedStatement pst1=conn.prepareStatement(str);
				 ResultSet set=pst1.executeQuery();
				 while(set.next())
					 temp=set.getInt(1);			 
				 logger.error("Insertion Successful");
			 }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error("Connection Error",e);
		//	e.printStackTrace();
			
		}
		
		return temp;
	}
	
	public void getDemandDraftDetails(int a)
	{

		System.out.println("Your Demand Draft request have been successfully registered"
       		 +"along with "+ a);
		/*try(Connection conn=getDbConnection())
		{
			String sql="select * from demand_draft where transaction_Id='?'";
          java.sql.PreparedStatement pst=conn.prepareStatement(sql);
          

			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	
		}
*/	}

	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			
			//e.printStackTrace();
		}
		
		return null;
		
	}

}
