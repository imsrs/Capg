package com.xyz.test;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class testXyzBanking {

	@Mock
	private IDemandDraftDAO demanddraftdao;
	private IDemandDraftService demanddraftservice;
	
	
	@Before
	public void setup()
	{
		
		MockitoAnnotations.initMocks(this);
		demanddraftservice = new DemandDraftService(demanddraftdao);
	}
	
	
	
	@Test
	public void test_acc_with_proper_format()
	{
	    DemandDraft demand=new DemandDraft();
	    demand.setCustomer_name("nikhilll");
	    demand.setIn_favor_of("hii");
	    demand.setDd_amount(1);
	    demand.setDd_description("nothing");
	    demand.setDate_of_transaction(LocalDate.of(2000, 10, 10));
	    demand.setDd_commission(10);
	    demand.setPhone_number("7989499127");
	   
	    
	    
	    Mockito.when(demanddraftdao.addDemandDraftDetails(demand)).thenReturn(1);
	    
	    
	    demanddraftservice.addDemandDraftDetails(demand);
	    
	    Mockito.verify(demanddraftdao).addDemandDraftDetails(demand);
	    
	    
	}
	
}
