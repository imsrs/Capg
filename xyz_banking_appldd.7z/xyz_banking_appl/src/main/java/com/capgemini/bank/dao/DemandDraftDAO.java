package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;

import com.capgemini.bank.bean.DemandDraft;
import com.mysql.jdbc.PreparedStatement;

public class DemandDraftDAO implements IDemandDraftDAO {

	public int addDemandDraftDetails(DemandDraft demanddraft) {
		// TODO Auto-generated method stub
		String sql="insert into demand_draft(customer_name,in_favour_of,phone_number,date_of_transaction,dd_amount,dd_commission,dd_description) values(?,?,?,?,?,?,?)";
		String sql1="select * from demand_draft";
		try(Connection conn=getDbConnection())
		{
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			
			pst.setString(1, demanddraft.getCustomer_name());
			pst.setString(2, demanddraft.getIn_favor_of());
			pst.setString(3, demanddraft.getPhone_number());
			pst.setDate(4, Date.valueOf(demanddraft.getDate_of_transaction()));
			pst.setDouble(5, demanddraft.getDd_amount());
			pst.setDouble(6, demanddraft.getDd_commission());
			pst.setString(7, demanddraft.getDd_description());
			
			
			int count=pst.executeUpdate();
			
		   if(count>=1)
		   {
			   System.out.println("insertion done");
			   
			   java.sql.PreparedStatement pst1=conn.prepareStatement(sql1);
			   
			   ResultSet res=pst1.executeQuery();
			   
			   while(res.next())
			   {
				   if(res.getString(2).compareTo(demanddraft.getCustomer_name())==0 && res.getString(3).compareTo(demanddraft.getIn_favor_of())==0)
				   {
					   //System.out.println("no is"+res.getInt(1));
					   return res.getInt(1);
				   }
			   }
		   }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			
			//e.printStackTrace();
		}
		
		return null;
		
	}	
	

	
	public DemandDraft getDemandDraftDetails(int transaction_id) {
		// TODO Auto-generated method stub
		
		System.out.println("your demand draft request has been succesfully registered along with "+transaction_id);
		
		
		return null;
	}

}
