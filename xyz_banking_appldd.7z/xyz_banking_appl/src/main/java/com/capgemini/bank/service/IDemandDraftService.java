package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;

public interface IDemandDraftService {

	
	public int addDemandDraftDetails(DemandDraft demanddraft);
	public DemandDraft getDemandDraftDetails(int transaction_id); 
	
}
