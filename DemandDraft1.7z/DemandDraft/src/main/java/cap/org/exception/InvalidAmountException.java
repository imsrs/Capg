package cap.org.exception;

public class InvalidAmountException extends Exception {

	public InvalidAmountException(String str)
	{
	super(str);
	}
}
