package com.org.view;

import java.time.LocalDate;
import java.util.Scanner;

import com.org.model.DemandDraft;
import com.org.service.DemandDraftService;

//import utilPackage.Utility;

public class Client {
	
	Scanner s=new Scanner(System.in);
	DemandDraftService ddservice=new DemandDraftService();

	
	public DemandDraft add_demanddraft_details()
	{
		DemandDraft demanddraft=new DemandDraft();
		System.out.println("Enter the Custiomer Name ");
		demanddraft.setCustomer_Name(Cust_name());
		System.out.println("Enter In favour of name ");
		String favour;
		favour=s.nextLine();
		demanddraft.setIn_Favour_Of(favour);
		System.out.println("Enter the mobile No");
		demanddraft.setPhone_number(Cust_number());
		System.out.println("Enter DateOfBirth[dd-mm-yyyy]:");	
		demanddraft.setDate_of_transaction(dd_date());		
		System.out.println("Enter the amount");
		double am=s.nextDouble();
		demanddraft.setDd_amount(am);
		System.out.println("Enter the DD Description");
		demanddraft.setDd_description(s.next());
		demanddraft.setDd_commission(cal_commission(am));
		
		return demanddraft;
	}
	
	public String Cust_name()
	{
		String name;
		boolean flag=false;
		do {
			name=s.nextLine();
			flag=ddservice.isvalidname(name);
			if(!flag)
				System.out.println("Invalid Name");
		}while(!flag);
		
		return name;
	}

	public String Cust_number()
	{
		String num;
		boolean flag=false;
		do {
			num=s.nextLine();
			flag=ddservice.isvalidnumber(num);
			if(!flag)
				System.out.println("Invalid Number");
		}while(!flag);
		
		return num;
	}
	
	public int cal_commission(double am)
	{
	  if (am<=5000)
		  return 10;
	  else if(am>5000 && am<10000)
		  return 41;
	  else if(am>10000 && am<100000)
		  return 51;
	  else if(am>100000 && am<500000)
		  return 306;
	return 0;
	}
	
	public LocalDate dd_date() {
		boolean flag=false;
		String date;
		do {			
			date=s.next();
			flag=ddservice.isValidDate(date);
			if(!flag)
				System.out.println("Please enter Valid Date!");
		}while(!flag);
		String[] dates=date.split("-");
		LocalDate dd_date=LocalDate.of(Integer.parseInt(dates[2]), 
				Integer.parseInt(dates[1]), Integer.parseInt(dates[0]));
		return dd_date;
	}
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		int choice;
		char ch;
		Client client=new Client();
		DemandDraft dddraft=new DemandDraft();
		DemandDraftService ddservice=new DemandDraftService();
		do
		{

		System.out.println("Enter the choice ");
		System.out.println("1.Enter Demand Draft Details \n2.Exit");
		choice=s.nextInt();
					switch(choice)
			{
			case 1 : dddraft=client.add_demanddraft_details();
			         int a=ddservice.add_demanddraft_details(dddraft);
			         ddservice.getDemandDraftDetails(a);
				     break;
			case 2 : System.exit(0);
			     break;
			default : System.out.println("Invalid Option");
			
			}
			System.out.println("Want to continue? [Y/N]");
			ch=s.next().charAt(0);
		}while(ch=='y' || ch=='Y');
	}


}
