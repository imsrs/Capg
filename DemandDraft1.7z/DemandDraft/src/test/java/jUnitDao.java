import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.org.DAO.DemandDraftDao;
import com.org.DAO.IDemandDraftsDao;
import com.org.model.DemandDraft;
import com.org.service.DemandDraftService;
import com.org.service.IDemanddraftService;

public class jUnitDao {

	@Mock
	private IDemandDraftsDao idddao;
	private IDemanddraftService serv;
	
	@Before
	public void setup()
	{
		MockitoAnnotations.initMocks(this);	
		serv=new DemandDraftService(idddao);
	}
	
	
	@Test
	public void test() {

	DemandDraft dd= new DemandDraft();
	
	dd.setTransaction_Id(10005);
	dd.setCustomer_Name("Shrey");
	dd.setIn_Favour_Of("Capgemini");
	dd.setPhone_number("8866429311");
	dd.setDate_of_transaction(LocalDate.now());
	dd.setDd_amount(50000);
	dd.setDd_commission(15);
	dd.setDd_description("Hello");
		
	Mockito.when(methodCall).
	}

}
