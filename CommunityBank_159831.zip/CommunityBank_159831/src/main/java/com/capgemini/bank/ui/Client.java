package com.capgemini.bank.ui;

import java.time.LocalDate;
import java.util.Scanner;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class Client {

static Scanner sc=new Scanner(System.in);
	
	public DemandDraft getDemandDraft()
	{
		
		DemandDraft demanddraft=new DemandDraft();
		
	    demanddraft.setCustomerName(promptcustomername());
	   
	    
	    demanddraft.setInFavorOf(promptinfavorof());
	    
	    demanddraft.setPhoneNumber(promptphonenumber());
	   
	    demanddraft.setDateOfTransaction(promptdateoftrans());
	    
		demanddraft.setDdAmount(promptddamount());
		
		demanddraft.setDescription(promptdddescription());
		
		demanddraft.setDdCommission(promptddcalculate(demanddraft.getDdAmount()));
		
		
		
		return demanddraft;
	}
	
	
	
	private double promptddcalculate(double dd_amount) {
		
		
		if(dd_amount<=5000)
		{
			return (10+dd_amount);
		}
		else if(dd_amount>5000 && dd_amount<=10000)
		{
			return (41+dd_amount);
		}
		else if(dd_amount>10000 && dd_amount<=100000)
		{
			return (51+dd_amount);
		}
		else
		{
			return (306+dd_amount);
		}
		
	}



	private String promptdddescription() {
		
		System.out.println("DD Description");
		String str=sc.next();
		
		return str;
	}



	private double promptddamount() {
		
		
	   double amount;
	  
	   System.out.println("Enetr Demand Draft Amount (in Rs):");
	   
	   amount=sc.nextDouble();
	   
	   
		
		return amount;
	}



	private LocalDate promptdateoftrans() {
	
		System.out.println(" Date of Transaction in [dd-mm-yyyy] Format");
		
		String dateoftrans=sc.next();
		
		String date1[]=dateoftrans.split("-");
		
		return LocalDate.of(Integer.parseInt(date1[2]), Integer.parseInt(date1[1]), Integer.parseInt(date1[0]));
	
	}



	private String promptphonenumber() {
		
		boolean flag=true;
		String mobileno;
		do
		{
		System.out.println("Mobile no of the Customer");
		
		 mobileno=sc.next();
		
		if(!mobileno.matches("(7|8|9){1}[0-9]{9}"))
		{
			flag=false;
		}
		
		
		}while(!flag);
		
		return mobileno;
	}



	private String promptinfavorof() {
		
		boolean flag=true;
		String infavorof;
		do
		{
		System.out.println(" In Favor Of");
		
		 infavorof=sc.next();
		
		if(!infavorof.matches("[a-zA-Z]+"))
		{
			flag=false;
		}
		
		
		}while(!flag);
		
		return infavorof;
	}



	private String promptcustomername() {
		
		boolean flag=true;
		String cust_Name;
		do
		{
		System.out.println("Customer Name");
		
		 cust_Name=sc.next();
		
		if(!cust_Name.matches("[a-zA-Z]+"))
		{
			flag=false;
		}
		
		
		}while(!flag);
		
		return cust_Name;
	}



	public static void main(String[] args) {
		

		Client client=new Client();
		
		IDemandDraftService ddservice = new DemandDraftService();
		
		while(true)
		{
			System.out.println("Display menu to the employee should be as follows\n\t"
					+ "1) Enter Demand Draft Details\n\t2) Exit");
			int ch=sc.nextInt();
			
			
			if(ch==1)
			{
				DemandDraft newDraft= client.getDemandDraft();
				int count=ddservice.addDemandDraftDetails(newDraft);
				
				ddservice.getDemandDraftDetails(count);
				}
		}
		
		
	}
}
