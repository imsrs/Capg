package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;

public class DemandDraftDAO implements IDemandDraftDAO {

	
	//inserting into database
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) {
		String sql="insert into demand_draft(customer_name,in_favor_of,phone_number,date_of_transaction,dd_amount,dd_commission,dd_descripion) values(?,?,?,?,?,?,?)";
		String sql1="select * from demand_draft";
		try(Connection conn=getDbConnection())
		{
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			
			pst.setString(1, demandDraft.getCustomerName());
			pst.setString(2, demandDraft.getInFavorOf());
			pst.setString(3, demandDraft.getPhoneNumber());
			pst.setDate(4, Date.valueOf(demandDraft.getDateOfTransaction()));
			pst.setDouble(5, demandDraft.getDdAmount());
			pst.setDouble(6, demandDraft.getDdCommission());
			pst.setString(7, demandDraft.getDescription());
			
			
			int count=pst.executeUpdate();
			
		   if(count>=1)
		   {
			   System.out.println("Data Inserted");
			   
			   java.sql.PreparedStatement pst1=conn.prepareStatement(sql1);
			   
			   ResultSet res=pst1.executeQuery();
			   
			   while(res.next())
			   {
				   if(res.getString(2).compareTo(demandDraft.getCustomerName())==0 && res.getString(3).compareTo(demandDraft.getInFavorOf())==0)
				   {
					   
					   return res.getInt(1);
				   }
			   }
		   }
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return 0;
	}

	
		
	
  
	@Override
	public DemandDraft getDemandDraftDetails(int transactionid) {
System.out.println("your demand draft request has been succesfully registered along with "+"< "+transactionid+" >");
		
		
		return null;
	}
	
	

	

// setting connection with JDBC(database)
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			
			//e.printStackTrace();
		}
		
		return null;
		
	}
}
