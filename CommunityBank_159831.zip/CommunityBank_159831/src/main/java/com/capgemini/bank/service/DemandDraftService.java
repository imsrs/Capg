package com.capgemini.bank.service;

import org.apache.log4j.Logger;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exception.InvalidAmountException;

public class DemandDraftService implements IDemandDraftService {

	IDemandDraftDAO demandDraftDao=new DemandDraftDAO(); 
	
	final static Logger logger=Logger.getLogger(DemandDraftService.class);
	
	
	public DemandDraftService(IDemandDraftDAO demanddraftdao2) {
		
		this.demandDraftDao=demanddraftdao2;
	}

	public DemandDraftService() {
		
	}
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) {
		try {
			if(validdemanddraft(demandDraft))
			{
			return demandDraftDao.addDemandDraftDetails(demandDraft);
			}
			else
			{
				logger.error("this is log error");
				throw new InvalidAmountException("Amount cannot be Zero or Negative");
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
	return 2;
		
		
		
	}

	private boolean validdemanddraft(DemandDraft demandDraft) {
		
		
		if(demandDraft.getDdAmount()>0)
		{
			return true;
		}
		
		return false;
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionid) {
		
		
		return demandDraftDao.getDemandDraftDetails(transactionid);
	
		
	}

}
