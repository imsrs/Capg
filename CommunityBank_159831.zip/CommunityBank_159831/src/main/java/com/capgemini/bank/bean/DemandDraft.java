package com.capgemini.bank.bean;

import java.time.LocalDate;

public class DemandDraft {
	private int transactionNumber;
	private String customerName;
	private String inFavorOf;
	private String phoneNumber;
	private LocalDate dateOfTransaction;
	private double ddAmount;
	private double ddCommission;
	private String description;
	
	public DemandDraft()
	{
		
	}

	

	public DemandDraft(String customerName, String inFavorOf, String phoneNumber, LocalDate dateOfTransaction,
			double ddAmount, double ddCommission, String description) {
		super();
		this.customerName = customerName;
		this.inFavorOf = inFavorOf;
		this.phoneNumber = phoneNumber;
		this.dateOfTransaction = dateOfTransaction;
		this.ddAmount = ddAmount;
		this.ddCommission = ddCommission;
		this.description = description;
	}



	public DemandDraft(int transactionNumber, String customerName, String inFavorOf, String phoneNumber,
			LocalDate dateOfTransaction, double ddAmount, double ddCommission, String description) {
		super();
		this.transactionNumber = transactionNumber;
		this.customerName = customerName;
		this.inFavorOf = inFavorOf;
		this.phoneNumber = phoneNumber;
		this.dateOfTransaction = dateOfTransaction;
		this.ddAmount = ddAmount;
		this.ddCommission = ddCommission;
		this.description = description;
	}



	
	public int getTransactionNumber() {
		return transactionNumber;
	}



	public void setTransactionNumber(int transactionNumber) {
		this.transactionNumber = transactionNumber;
	}



	public String getCustomerName() {
		return customerName;
	}



	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}



	public String getInFavorOf() {
		return inFavorOf;
	}



	public void setInFavorOf(String inFavorOf) {
		this.inFavorOf = inFavorOf;
	}



	public String getPhoneNumber() {
		return phoneNumber;
	}



	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}



	public LocalDate getDateOfTransaction() {
		return dateOfTransaction;
	}



	public void setDateOfTransaction(LocalDate dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}



	public double getDdAmount() {
		return ddAmount;
	}



	public void setDdAmount(double ddAmount) {
		this.ddAmount = ddAmount;
	}



	public double getDdCommission() {
		return ddCommission;
	}



	public void setDdCommission(double ddCommission) {
		this.ddCommission = ddCommission;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	@Override
	public String toString() {
		return "DemandDraft [transactionNumber=" + transactionNumber + ", customerName=" + customerName + ", inFavorOf="
				+ inFavorOf + ", phoneNumber=" + phoneNumber + ", dateOfTransaction=" + dateOfTransaction
				+ ", ddAmount=" + ddAmount + ", ddCommission=" + ddCommission + ", description=" + description + "]";
	}



	



	
	
	
	
	
}
