package com.capgemini.bank.junit;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class JunitHandlingTest {

	
	@Mock
	private IDemandDraftDAO demanddraftdao;
	private IDemandDraftService demanddraftservice;
	
	
	@Before
	public void setup()
	{
		
		MockitoAnnotations.initMocks(this);
		demanddraftservice = new DemandDraftService(demanddraftdao);
	}
	
	
	
	@Test
	public void test_acc_with_proper_format()
	{
	    DemandDraft demand=new DemandDraft();
	    demand.setCustomerName("Pushkar");
	    demand.setInFavorOf("Hello");
	    demand.setDdAmount(1);
	    demand.setDescription("Nope");
	    demand.setDateOfTransaction(LocalDate.of(1996, 10, 03));
	    demand.setDdCommission(10);
	    demand.setPhoneNumber("9875641235");
	   
	    
	    
	    Mockito.when(demanddraftdao.addDemandDraftDetails(demand)).thenReturn(1);
	    
	    
	    demanddraftservice.addDemandDraftDetails(demand);
	    
	    Mockito.verify(demanddraftdao).addDemandDraftDetails(demand);
	    
	    
	}
}
