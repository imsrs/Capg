export interface IProduct{
    customerId:number;
    firstName:string;
    lastName:string;
    dateOfBirth:string;
    emailId:String;
    mobile:string;
    customerPwd:string;
    
}