import { Injectable } from "@angular/core";
import { IProduct } from "./IProduct";
import { HttpClient, HttpErrorResponse ,HttpHeaders} from "@angular/common/http";
import { Observable } from "rxjs/Observable";

import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
 
const httpOptions = {
headers: new HttpHeaders({
'Content-Type': 'application/json',
'Authorization': 'my-auth-token'
})
}; 
 

@Injectable()
export class ProductService{
    private _productUrl='http://localhost:8080/day3-Spring5Rest/api/customers';
   url:string;
    constructor(private _http: HttpClient)
    {

    }
getProducts():Observable<IProduct[]>{
    return this._http.get<IProduct[]>(this._productUrl).do(data => console.log('All: '+ JSON.stringify(data)))
                .catch(this.handleError);
}
    private handleError(err: HttpErrorResponse) {
        console.error(err.message);
        return Observable.throw(err.message);
    }

    deleteProduct(id:number): Observable<{}>{
    //const url = `${this._productUrl}/${id}`;
    this.url=this._productUrl+'/'+id;
    return this._http.delete(this.url, httpOptions);
    } 
     
    
}