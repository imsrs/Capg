import { Component, OnInit } from '@angular/core';
import { IProduct } from './IProduct';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'pm-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {

  constructor(private _route: ActivatedRoute , private _router:Router) { 
    //console.log(this._route: )
  }

  onBack(): void {
      this._router.navigate(['/products']);

  }

  pageTitle:string = 'Product-Detail';
  product:IProduct;

  ngOnInit() {
    let id= +this._route.snapshot.paramMap.get('id');

    this.pageTitle += `: ${id}`;
  
    
  }

}
