import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { ProductListComponent } from './Product/product-list.component';
import {FormsModule} from '@angular/forms';
import { convertToSpacesPipe } from './shared/convert-to-space.pipe';
import { ProductService } from './Product/product.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import {RouterModule} from '@angular/router';
import { WelcomeComponent } from './home/welcome.component';



@NgModule({
  declarations: [
    AppComponent,ProductListComponent,convertToSpacesPipe,WelcomeComponent
   
  ],
  imports: [
    BrowserModule, FormsModule,HttpClientModule,
    RouterModule.forRoot([
      {path: 'products', component: ProductListComponent},
      
      {path: 'welcome', component: WelcomeComponent },
      {path: '', redirectTo:'welcome', pathMatch:'full'},
      {path:'**', redirectTo:'welcome', pathMatch:'full'}

  ])
  ],
  providers: [ProductService],
  bootstrap: [AppComponent,ProductListComponent,WelcomeComponent]
})
export class AppModule { }
