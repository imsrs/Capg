package view;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import model.Account;
import model.Address;
import model.Customer;
import model.Transaction;
import service.CustomerServiceImpl;
import service.ICustomerService;

public class UserInteraction {

	Scanner sc=new Scanner(System.in);
	public Customer getCustomerDetails() {

		Customer customer=new Customer();
		System.out.print("Enter customer First name: ");
		String firstName=sc.next();
		while(!firstName.matches("[a-zA-Z ]+")) {
			System.out.print("Invalid!\n Enter First name again: ");
			firstName = sc.next();
		}
		customer.setFirstName(firstName);
		
		System.out.print("Enter customer Last name: ");
		String lastName=sc.next();
		while(!lastName.matches("[a-zA-Z ]+")) {
			System.out.print("Invalid!\n Enter Last name again: ");
			lastName = sc.next();
		}
		customer.setLastName(lastName);
		
		LocalDate dateOfBirth;
		System.out.println("Enter date of birth:");
		System.out.print("Enter year:");
		int year=sc.nextInt();
		System.out.print("Enter Month:");
		int month=sc.nextInt();
		System.out.print("Enter dayOfMonth:");
		int dayOfMonth=sc.nextInt();
		dateOfBirth=LocalDate.of(year, month, dayOfMonth);
		customer.setDateOfBirth(dateOfBirth);
		
		String emailId;
		System.out.print("Enter Email Id: ");
		emailId=sc.next();
		while(!emailId.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"  
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")) {
			System.out.print("Invalid!\n Enter Email Id again: ");
			emailId = sc.next();
		}
		customer.setEmailId(emailId);
		
		String mobileNo;
		System.out.print("Enter Mobile Number: ");
		mobileNo=sc.next();
		while(!mobileNo.matches("\\d{10}")) {
			System.out.print("Invalid!\n Enter Mobile Number again: ");
			mobileNo = sc.next();
		}
		customer.setMobileNo(mobileNo);
		
		Address address=new Address();
		
		address=getAddressDetails();
		customer.setAddress(address);
		
		return customer;
	}

	public Address getAddressDetails() {

		Address address=new Address();
		
		System.out.print("Enter Address Line1: ");
		String addressLine1=sc.next();
		address.setAddressLine1(addressLine1);
		
		System.out.print("Enter Address Line2: ");
		String addressLine2=sc.next();
		address.setAddressLine2(addressLine2);
		
		System.out.print("Enter City: ");
		String city=sc.next();
		address.setCity(city);
		
		System.out.print("Enter State: ");
		String state=sc.next();
		address.setState(state);
		
		System.out.print("Enter pincode: ");
		String pincode=sc.next();
		address.setPincode(pincode);
		
		return address;
	}

	public void createCustomer(Customer customer) {

		ICustomerService customerService=new CustomerServiceImpl();
		customerService.createCustomer(customer);
		
	}

//	public void printDetails(Set<Customer> customers) {
//
//		for(Customer customer:customers) {
//			System.out.println(customer);
//			
//		}
//	}

	public Account getAccountDetails(int customerId) {
		Account account =new Account();
		System.out.print("Enter Account Type- Saving,Current,RD,FD: ");
		String accountType=sc.next();
		account.setAccountType(accountType);
		
		System.out.println("Enter Opening Date ");
		LocalDate openingDate;
		System.out.print("Enter year:");
		int year=sc.nextInt();
		System.out.print("Enter Month:");
		int month=sc.nextInt();
		System.out.print("Enter dayOfMonth:");
		int dayOfMonth=sc.nextInt();
		openingDate=LocalDate.of(year, month, dayOfMonth);
		account.setOpeningDate(openingDate);
		
		System.out.print("Enter Opening Balance: ");
		double openingBalance=sc.nextDouble();
		account.setOpeningBalance(openingBalance);
		
		System.out.print("Enter Description: ");
		String description=sc.next();
		account.setDescription(description);
		
		account.setCustomerId(customerId);
		return account;
	}

	public Customer chooseCustomer() {
		ICustomerService customerService=new CustomerServiceImpl();
		
		Set<Customer> customers= customerService.getAllCustomer();
		System.out.println(customers);
		int customerId;
		System.out.println("Choose customer ID: ");
		customerId=sc.nextInt();
		for(Customer customer:customers)
			if(customer.getCustomerId()==customerId)
			{
				return customer;
			}
		return null;
	}
	
	public Account createAccount(Account account) {
		
		ICustomerService customerService=new CustomerServiceImpl();
		return customerService.createAccount(account);
	}

	public void doTransaction(int customerId,int accountNumber) {

		ICustomerService customerService=new CustomerServiceImpl();
		Transaction transaction=new Transaction();
		
		System.out.println("1.) Deposit");
		System.out.println("2.) Withdraw");
		System.out.println("3.) Fund Transfer");
		System.out.println("Choose option:");
		int option=sc.nextInt();
		switch(option)
		{
		case 1:
			transaction.setToAccount(accountNumber);
			System.out.println("Enter amount to be deposited");
			double amount=sc.nextDouble();
			
			transaction.setTransactionType("Deposit");
			transaction.setFromAccount(0);
			transaction.setAmount(amount);
			System.out.println("Enter description of transaction: ");
			String description=sc.next();
			transaction.setDescription(description);
			transaction.setTransactionDate(LocalDate.now());
			
			customerService.deposit(amount,transaction,customerId);
			break;
		case 2:
			transaction.setFromAccount(accountNumber);
			System.out.println("Enter amount to be withdrawn");
			 amount=sc.nextDouble();
			if(amount<getCurrentBalance(customerId, accountNumber))
			{
			transaction.setTransactionType("Withdraw");
			transaction.setToAccount(0);
			transaction.setAmount(amount);
			System.out.println("Enter description of transaction: ");
			 description=sc.next();
			transaction.setDescription(description);
			transaction.setTransactionDate(LocalDate.now());
			
			customerService.withdraw(amount,transaction,customerId);
			}
			else
				System.out.println("Invalid amount");
			break;
		case 3:
			transaction.setFromAccount(accountNumber);
			
			System.out.println("Enter Account info for funds transfer");
			Customer customer=chooseCustomer();
			List<Account> accounts=customerService.getAccountDetails(customer.getCustomerId());
			System.out.println("Account Number | Account Type | OpeningDate | Opening Balance | Description");
			for(Account acc:accounts)
			{
				System.out.println(acc.getAccountNumber()+" "+acc.getAccountType()+" "+acc.getOpeningDate()+" "+
						acc.getOpeningBalance()+" "+acc.getDescription());
			}
			System.out.println("Choose account No: ");
			int accountNumber2=sc.nextInt();
			transaction.setToAccount(accountNumber2);
			
			System.out.println("Enter amount: ");
			 amount=sc.nextDouble();
			 if(amount<getCurrentBalance(customerId, accountNumber))
				{
			transaction.setTransactionType("FundTransfer");
			transaction.setAmount(amount);
			System.out.println("Enter description of transaction: ");
			 description=sc.next();
			transaction.setDescription(description);
			transaction.setTransactionDate(LocalDate.now());
			
			customerService.fundTransfer(amount,transaction,customerId);
				}
			 else 
				 System.out.println("Invalid Amount");
			break;
		default:
			System.out.println("Not a valid option");
		}
		
	}

	double getCurrentBalance(int customerId,int accountNumber)
	{
		ICustomerService customerService=new CustomerServiceImpl();
		double currentBalance=0;
		List<Account> accounts=customerService.getAccountDetails(customerId);
		for(Account account:accounts)
		{
			if(account.getAccountNumber()==accountNumber)
				currentBalance=account.getOpeningBalance();
		}
		List<Transaction> transactions=customerService.getTransactionDetails();
		for(Transaction trans:transactions)
		{
			if(trans.getFromAccount()==accountNumber)
				currentBalance+=trans.getAmount();
			if(trans.getToAccount()==accountNumber)
				currentBalance-=trans.getAmount();
		}
		return accountNumber;
		
	}
	

}
