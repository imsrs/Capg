package services;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import dao.CustomerDaoImpl;
import dao.ICustomerDao;
import model.Account;
import model.Customer;
import model.Transaction;

public class CustomerServiceImpl implements ICustomerService{
	
	private ICustomerDao customerDao=new CustomerDaoImpl();
	
	

	@Override
	public void createCustomer(Customer customer) {
		if(isValidCustomer(customer)) {
					customerDao.createCustomer(customer);
		}
		
	}
	public void AddAccount(Customer customer,Account account)
	{
		customerDao.AddAccount( customer, account);
	}
	
	private boolean isValidCustomer(Customer customer) {
		boolean flag=false;
		
		if(customer.getDateOfBirth().isBefore(LocalDate.now())) {
			if(customer.getMobile().matches("(6|7|8|9)\\d{9}"))
				flag=true;
			else
				flag=false;
		}else
			flag=false;
		
		
		return flag;
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		return customerDao.getAllCustomers();
	}
        @Override
	public Customer isCustomerFound(int customerId)
	{
		return customerDao.isCustomerFound(customerId);
		
	}
        public Account isAccountFound(Customer customer,int accountNumber)
        {
            return customerDao.isAccountFound(customer,accountNumber);
        }
        public void addTransaction(Transaction transaction)
        {
            customerDao.addTransaction(transaction);
        }
        @Override
	public List<Transaction> getAllTransaction()
        {
            return customerDao.getAllTransaction();
        }
        @Override
        public double getCurrentBalance(Account account,int accountNumber)
        {
            return customerDao.getCurrentBalance( account,accountNumber);
        }
}
