package deposit;
import static org.junit.Assert.assertNull;

import org.cap.dao.IAccountDao;
import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.service.AccountServiceImpl;
import org.cap.service.IAccountService;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {
	
	@Rule
	public ExpectedException thrown=ExpectedException.none();
	private double balance;
	
	private IAccountService accountService;
	
	
	private Account account;
	
	@Mock
	private IAccountDao accountDao;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		accountService=new AccountServiceImpl(accountDao);
		
	}
	
	@Given("^Account details$")
	public void account_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Address address=new Address("23 North avvenue","Chennai");
		Customer customer=new Customer("Tom", "Jerry", address);
		account=new Account(1001,customer,5000);
	}

	@When("^Valid Account Details$")
	public void valid_Account_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  assertNull(account);
	}

	@Then("^Deposit amount to Account$")
	public void deposit_amount_to_Account() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^Account details and current balance$")
	public void account_details_and_current_balance() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Invalid account details$")
	public void invalid_account_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^throw error message 'Invalid Account Details'$")
	public void throw_error_message_Invalid_Account_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
