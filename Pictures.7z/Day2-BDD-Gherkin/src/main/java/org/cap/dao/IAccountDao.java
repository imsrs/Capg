package org.cap.dao;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Transaction;



public interface IAccountDao {

	public boolean createAccount(Account account);
	public boolean deposit(double amount,Transaction transaction,int customerId);

	

	public boolean withdraw(double amount, Transaction transaction,int customerId);

	public boolean fundTransfer(double amount, Transaction transaction,int customerId);
	
	
}
