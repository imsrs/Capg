package view;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import model.AccountType;
import model.Address;
import model.Customer;
import model.Account;
import model.Transaction;
import services.CustomerServiceImpl;
import utilPackage.Utility;
import services.ICustomerService;

public class UserInteraction {

    Scanner sc=new Scanner(System.in);
    ICustomerService customerService=new CustomerServiceImpl();
    public Transaction doTransaction(Customer customer) 
    {
        System.out.println("Choose your option:");
        System.out.println("1.Deposit");
        System.out.println("2.Withdrawal");
        System.out.println("3.Funds Transfer");
        double amount = 0;
        int accountNumber=0;
        int transactionType=sc.nextInt();
        Account account=new Account();
        Transaction transaction=new Transaction();
        switch(transactionType)
        {
            case 1:
                System.out.println("Choose account to deposit:");
                printAccounts(customer.getAccounts());
                accountNumber=sc.nextInt();
                account=customerService.isAccountFound(customer,accountNumber);
                if(account==null)
                {
                    System.out.println("Account does not exist for customer id- "+customer.getCustomerId());
                    break;
                }
                transaction.setTransactionType("Deposit");
                System.out.println("Enter amount to be deposited");
                amount=sc.nextDouble();
                transaction.setToAccount(account);
                transaction.setFromAccount(null);
                
                System.out.println("Amout Deposited Successfully!");
                
                break;
            case 2:
                System.out.println("Choose account to withdraw:");
                printAccounts(customer.getAccounts());
                accountNumber=sc.nextInt();
                account=customerService.isAccountFound(customer,accountNumber);
                 if(account==null)
                {
                    System.out.println("Account does not exist for customer id- "+customer.getCustomerId());
                    break;
                }
                 transaction.setTransactionType("Withdrawal");
                 System.out.println("Enter amount to be withdrawn");
                amount=sc.nextDouble();
                while(amount>customerService.getCurrentBalance(account, accountNumber))
                {
                    System.out.println("Invalid!Amount should be less than current balance.");
                    amount=sc.nextDouble();
                }
                transaction.setToAccount(null);
                transaction.setFromAccount(account);
                System.out.println("Amout withdrawn Successfully!");
                break;
            case 3:
                System.out.println("Choose account to deposit funds:");
                printAccounts(customer.getAccounts());
                int toAccountNumber=sc.nextInt();
                account=customerService.isAccountFound(customer,toAccountNumber);
                 if(account==null)
                {
                    System.out.println("Account does not exist for customer id- "+customer.getCustomerId());
                    break;
                }
                transaction.setToAccount(account);
                System.out.println("Choose account to credit funds:");
                printAccounts(customer.getAccounts());
                int fromAccountNumber=sc.nextInt();
                account=customerService.isAccountFound(customer,fromAccountNumber);
                 if(account==null)
                {
                    System.out.println("Account does not exist for customer id- "+customer.getCustomerId());
                    break;
                }
                transaction.setFromAccount(account);
                transaction.setTransactionType("Fund Transfer");
                
                System.out.println("Enter amount to transfer");
                amount=sc.nextDouble();
                
                break;
            default:
                System.out.println("Invalid choice!");
                return null;
            }
        System.out.println("Enter description of transaction");
        String description=sc.next();
        transaction.setDescription(description);
        transaction.setAmount(amount);
        transaction.setTransactionId(Utility.generateNumber());
        transaction.setTransactionDate(LocalDate.now());
        return transaction;
    }
    
    public void printSummary(List<Transaction> transactions)
    {
        System.out.println("TransactionId|TransactionDate|ToAccount\t\t|FromAccount\t\t|amount|TransactionType|Description");
	System.out.println("------------------------------------------------------------------------------------------------------------------------");
	for(Transaction transaction:transactions) {
            System.out.println(transaction.getTransactionId()+"\t"+transaction.getTransactionDate()+"\t"+
                    transaction.getToAccount()+"\t"+transaction.getFromAccount()+"\t"+transaction.getAmount()+"\t"+
                    transaction.getTransactionType()+"\t"+transaction.getDescription());
		}
    }
       
	public void printCustomers(List<Customer> customers) {
		System.out.println("CustomerId\tCustomerName\tEmailId\t\tMobile");
		System.out.println("-----------------------------------------------------------------------------");
		
		for(Customer customer:customers) {
			System.out.println(customer.getCustomerId()
					+"\t\t"+customer.getFirstName()+" " + customer.getLastName()
					+"\t"+ customer.getEmailId() + "\t" + customer.getMobile() );
		}
	}
	public void printCustomersAccounts(List<Customer> customers) {
		System.out.println("CustomerId\tCustomerName\tEmailId\t\tMobile");
		System.out.println("-----------------------------------------------------------------------------");
		
		for(Customer customer:customers) {
			System.out.println(customer.getCustomerId()
					+"\t\t"+customer.getFirstName()+" " + customer.getLastName()
					+"\t"+ customer.getEmailId() + "\t" + customer.getMobile());
		}
		System.out.println("Choose customer: ");
		int customerId=sc.nextInt();
		Customer customer=customerService.isCustomerFound( customerId);
		
		System.out.println(customer.getAccounts());
	}
	public Customer getCustomerDetails() {
		
		Customer customer=new Customer();
		
		customer.setCustomerId(Utility.generateNumber());
		customer.setFirstName(promptFirstName());
		customer.setLastName(promptLastName());
		customer.setEmailId(promptEmailId());
		customer.setMobile(promptMobile());
		customer.setDateOfBirth(promptDateOfBirth());
		customer.setAddress(getAddressDetails());
                customer.setAccounts(new HashSet<Account>());
		return customer;
	}
	
	public Account getAccountDetails()
	{
		Account account=new Account();
		account.setAccountNumber(Utility.generateNumber());
		account.setAccountType(promptAccountType());
		account.setOpeningDate(promptOpeningDate());
		account.setOpeningBalance(promptOpeningBalance());
		account.setDescription(promptDescription());
		return account;
		
	}
        public void printAccounts(Set<Account> accounts) {
		System.out.println("Account No|Account Type|Opening Date|Opening Balance|description");
		System.out.println("-------------------------------------------------------------------");
		for(Account account:accounts) {
			System.out.println(account.getAccountNumber()
					+"\t\t"+account.getAccountType()+" " + account.getOpeningDate()
					+"\t"+ account.getOpeningBalance() + "\t" + account.getDescription() );
		}
	}
        
	public AccountType promptAccountType()
	{
		System.out.println("Choose Account Type[1,2,3,4]:");
		printAccountType();
		int accountTypeNo=sc.nextInt();
		switch(accountTypeNo) {
		case 1:
			return AccountType.SAVINGS;
		case 2:
			return AccountType.CURRENT;
		case 3:
			return AccountType.RD;
		case 4:
			return AccountType.FD;
		default:
			System.out.println("Invalid Account Type");
			System.exit(0);
		}
		
		return null;
	}
	public void printAccountType()
	{
		AccountType[] types=AccountType.values();
		int count=0;
		for(AccountType type:types)
			System.out.println(++count + "." + type);
	}
	public LocalDate promptOpeningDate()
	{
		System.out.println("Enter account OpeningDate:");
		System.out.println("Enter year:");
		int year=sc.nextInt();
		System.out.println("Enter Month:");
		int month=sc.nextInt();
		System.out.println("Enter dayOfMonth:");
		int dayOfMonth=sc.nextInt();
		LocalDate date=LocalDate.of(year, month, dayOfMonth);
		return date;
	}
	public double promptOpeningBalance()
	{
		System.out.println("Enter Opening Balance:");
		double openingBalance=sc.nextDouble();
		return openingBalance;
	}
	public String promptDescription()
	{
		System.out.println("Enter Description:");
		String description=sc.next();
		return description;
	}
	public Address getAddressDetails() {
		Address address=new Address();
		System.out.println("Enter AddressLine1:");
		address.setAddressLine1(sc.next());
		System.out.println("Enter AddressLine2:");
		address.setAddressLine2(sc.next());
		System.out.println("Enter City:");
		address.setCity(sc.next());
		System.out.println("Enter State:");
		address.setState(sc.next());
		address.setPincode(promptPincode());
		return address;
	}
	
	public String promptPincode() {
		boolean flag=false;
		String pincode;
		do {
			System.out.println("Enter pincode:");
			pincode=sc.next();
			flag=Utility.isValidPincode(pincode);
			if(!flag)
				System.out.println("Please enter Valid pincode!");
		}while(!flag);
		
		return pincode;
	}

	public LocalDate promptDateOfBirth() {
		boolean flag=false;
		String dob;
		do {
			System.out.println("Enter DateOfBirth[dd-mm-yyyy]:");
			dob=sc.next();
			flag=Utility.isValidDob(dob);
			if(!flag)
				System.out.println("Please enter Valid Date!");
		}while(!flag);
		String[] dates=dob.split("-");
		LocalDate date=LocalDate.of(Integer.parseInt(dates[2]), 
				Integer.parseInt(dates[1]), Integer.parseInt(dates[0]));
		return date;
	}
	
	public String promptMobile() {
		boolean flag=false;
		String mobile;
		do {
			System.out.println("Enter mobile Number:");
			mobile=sc.next();
			flag=Utility.isValidMobile(mobile);
			if(!flag)
				System.out.println("Please enter Valid 10 digit Mobile!");
		}while(!flag);
		
		return mobile;
	}
	
	public String promptFirstName() {
		boolean flag=false;
		String fname;
		do {
			System.out.println("Enter FirstName:");
			fname=sc.next();
			flag=Utility.isValidName(fname);
			if(!flag)
				System.out.println("Please enter Valid FirstName!");
		}while(!flag);
		
		return fname;
	}
	
	public String promptLastName() {
		boolean flag=false;
		String fname;
		do {
			System.out.println("Enter LastName:");
			fname=sc.next();
			flag=Utility.isValidName(fname);
			if(!flag)
				System.out.println("Please enter Valid LastName!");
		}while(!flag);
		
		return fname;
	}
	
	public String promptEmailId() {
		boolean flag=false;
		String email;
		do {
			System.out.println("Enter EmailId:");
			email=sc.next();
			flag=Utility.isValidEmail(email);
			if(!flag)
				System.out.println("Please enter Valid EmailId!");
		}while(!flag);
		
		return email;
	}


	public void printError(String message) {
		System.out.println(message);
		
	}
	
	
}
