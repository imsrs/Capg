package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import model.Account;
import model.Address;
import model.Customer;
import model.Transaction;

public class customerDaoImpl implements ICustomerDao {
	
	Set<Customer> customers=new HashSet<>();
	
	private Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/parallelproject", "root", "India123");
			return connection;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void createCustomer(Customer customer) {

		String sql1="Insert into customer(firstName ,lastName ,dateOfBirth,emailId ,mobile) values(?,?,?,?,?)";
		try(Connection connection=getConnection()){
			PreparedStatement pst=connection.prepareStatement(sql1);
			pst.setString(1, customer.getFirstName());
			pst.setString(2, customer.getLastName());
			pst.setDate(3, Date.valueOf(customer.getDateOfBirth()));
			pst.setString(4, customer.getEmailId());
			pst.setString(5, customer.getMobileNo());
			
			int count=pst.executeUpdate();
			if(count>0)
			{
				int customerId = 0;
				String sql2="select max(customerId) from customer";
				try(PreparedStatement pst2=getConnection().prepareStatement(sql2))
				{
					ResultSet rs=pst2.executeQuery();
					if(rs.next())
						customerId=rs.getInt(1);
				
				String sql3="Insert into address(addressLine1,addressLine2,city,state,pincode,customerId) values(?,?,?,?,?,?)";
				try(PreparedStatement pst3=getConnection().prepareStatement(sql3))
				{
					pst3.setString(1, customer.getAddress().getAddressLine1());
					pst3.setString(2, customer.getAddress().getAddressLine2());
					pst3.setString(3,customer.getAddress().getCity());
					pst3.setString(4,customer.getAddress().getState());
					pst3.setString(5,customer.getAddress().getPincode());
					pst3.setInt(6,customerId);
					int count3=pst3.executeUpdate();
					if(count3==0)
						System.out.println("error occured");
				}
				}
				
				
			}else { System.out.println("error occured");}
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		
	}

	@Override
	public Set<Customer> getAllCustomer() {

		//Set<Customer> customers=new HashSet<>();
		Customer customer=new Customer();
		String query="select * from customer";
		try(Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
			ResultSet resultSet= statement.executeQuery();
			while(resultSet.next()) {
				customer.setCustomerId(resultSet.getInt(1));
				customer.setFirstName(resultSet.getString(2));
				customer.setLastName(resultSet.getString(3));
				customer.setDateOfBirth(resultSet.getDate(4).toLocalDate());
				customer.setEmailId(resultSet.getString(5));
				customer.setMobileNo(resultSet.getString(6));
				customers.add(customer);
			}
			
			return customers;
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Address> getAllAddress() {

		Set<Address> addresses=new HashSet<>();
		Address address=new Address();
		String query="select * from address";
		try(Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
		statement=connection.prepareStatement(query);
		ResultSet resultSet= statement.executeQuery();
		while(resultSet.next()) {
			address.setAddressId(resultSet.getInt(1));
			address.setAddressLine1(resultSet.getString(2));
			address.setAddressLine2(resultSet.getString(3));
			address.setCity(resultSet.getString(4));
			address.setState(resultSet.getString(5));
			address.setPincode(resultSet.getString(6));
			address.setCustomerId(resultSet.getInt(7));
			addresses.add(address);
		}
		
		return addresses;
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Account createAccount(Account account) {

		String query = "INSERT INTO account (customerId,accountType,openingDate,openingBalance,description) VALUES(?,?,?,?,?)";
		try(Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1, account.getCustomerId());
			statement.setString(2,account.getAccountType());
			
			statement.setDate(3, java.sql.Date.valueOf(account.getOpeningDate()));
			statement.setDouble(4, account.getOpeningBalance());
			statement.setString(5, account.getDescription());
			
			
			int count = statement.executeUpdate();
			if(count>0) {
				//System.out.println("Account info inserted");
				query="select * from account";
				statement=connection.prepareStatement(query);
				ResultSet resultSet= statement.executeQuery();
				Account  account1=new Account();
				while(resultSet.next()) {
					account1.setAccountNumber(resultSet.getInt(1));
					account1.setCustomerId(resultSet.getInt(2));
					account1.setAccountType(resultSet.getString(3));
					account1.setOpeningDate(resultSet.getDate(4).toLocalDate());
					account1.setOpeningBalance(resultSet.getDouble(5));
					account1.setDescription(resultSet.getString(6));
					
				}
				return account;
			}else {System.out.println("Error occured.");}
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Account> getAccountDetails(int custId) {
		List<Account> accounts=new ArrayList<>();
		Account account=new Account();
		String query="select * from account where customerId=?";
		try(Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
		statement=connection.prepareStatement(query);
		statement.setInt(1, custId);
		ResultSet resultSet= statement.executeQuery();
		while(resultSet.next()) {
			account.setAccountNumber(resultSet.getInt(1));
			account.setCustomerId(resultSet.getInt(2));
			account.setAccountType(resultSet.getString(3));
			account.setOpeningDate(resultSet.getDate(4).toLocalDate());
			account.setOpeningBalance(resultSet.getDouble(5));
			account.setDescription(resultSet.getString(6));
			
			accounts.add(account);
		}
		
		return accounts;
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void deposit(double amount,Transaction transaction,int customerId) {

		String sql1="insert into transaction(transactionDate,fromAccountNumber,toAccountNumber,amount ,description,transactionType,customer_id) "
				+ "values(?,?,?,?,?,?,?)";
		try(Connection connection = getConnection()){
			PreparedStatement statement = connection.prepareStatement(sql1);
			statement.setDate(1,java.sql.Date.valueOf(transaction.getTransactionDate()));
			statement.setInt(2, transaction.getFromAccount());
			statement.setInt(3, transaction.getToAccount());
			statement.setDouble(4, transaction.getAmount());
			statement.setString(5, transaction.getDescription());
			statement.setString(6, transaction.getTransactionType());
			statement.setInt(7,customerId);
			int count=statement.executeUpdate();
			if(count<0)
				System.out.println("Error occured");
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		
	}
	@Override
	public void withdraw(double amount, Transaction transaction,int customerId) {
		String sql1="insert into transaction(transactionDate,fromAccountNumber,toAccountNumber,amount ,description,transactionType,customer_id) "
				+ "values(?,?,?,?,?,?,?)";
		try(Connection connection = getConnection()){
			PreparedStatement statement = connection.prepareStatement(sql1);
			statement.setDate(1,java.sql.Date.valueOf(transaction.getTransactionDate()));
			statement.setInt(2, transaction.getFromAccount());
			statement.setInt(3, transaction.getToAccount());
			statement.setDouble(4, transaction.getAmount());
			statement.setString(5, transaction.getDescription());
			statement.setString(6, transaction.getTransactionType());
			statement.setInt(7,customerId);
			int count=statement.executeUpdate();
			if(count<0)
				System.out.println("Error occured");
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		
	}

	@Override
	public List<Transaction> getTransactionDetails() {
		List<Transaction> transactions=new ArrayList<>();
		Transaction transaction=new Transaction();
		String query="select * from transaction";
		try(Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
		statement=connection.prepareStatement(query);
		ResultSet resultSet= statement.executeQuery();
		while(resultSet.next()) {
			transaction.setTransactionId(resultSet.getInt(1));
			transaction.setTransactionDate(resultSet.getDate(2).toLocalDate());
			transaction.setFromAccount(resultSet.getInt(3));
			transaction.setToAccount(resultSet.getInt(4));
			transaction.setAmount(resultSet.getDouble(5));
			transaction.setDescription(resultSet.getString(6));
			transaction.setTransactionType(resultSet.getString(7));
			transactions.add(transaction);
		}
		
		return transactions;
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void fundTransfer(double amount, Transaction transaction,int customerId) {
		String sql1="insert into transaction(transactionDate,fromAccount,toAccount,amount ,description,transactionType,customer_id) "
				+ "values(?,?,?,?,?,?,?)";
		try(Connection connection = getConnection()){
			PreparedStatement statement = connection.prepareStatement(sql1);
			statement.setDate(1,java.sql.Date.valueOf(transaction.getTransactionDate()));
			statement.setInt(2, transaction.getFromAccount());
			statement.setInt(3, transaction.getToAccount());
			statement.setDouble(4, transaction.getAmount());
			statement.setString(5, transaction.getDescription());
			statement.setString(6, transaction.getTransactionType());
			statement.setInt(7,customerId);
			int count=statement.executeUpdate();
			if(count<0)
				System.out.println("Error occured");
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		
	}
	
}
