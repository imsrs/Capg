package dao;

import java.sql.ResultSet;
import java.util.List;
import java.util.Set;

import model.Account;
import model.Address;
import model.Customer;
import model.Transaction;

public interface ICustomerDao {

	void createCustomer(Customer customer);

	Set<Customer> getAllCustomer();

	Set<Address> getAllAddress();

	Account createAccount(Account account);

	List<Account> getAccountDetails(int customerId);

	void deposit(double amount,Transaction transaction,int customerId);

	List<Transaction> getTransactionDetails();

	void withdraw(double amount, Transaction transaction,int customerId);

	void fundTransfer(double amount, Transaction transaction,int customerId);

}
