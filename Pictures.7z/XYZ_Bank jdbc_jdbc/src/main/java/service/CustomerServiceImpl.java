package service;

import java.sql.ResultSet;
import java.util.List;
import java.util.Set;

import dao.ICustomerDao;
import dao.customerDaoImpl;
import model.Account;
import model.Address;
import model.Customer;
import model.Transaction;

public class CustomerServiceImpl implements ICustomerService {

	@Override
	public void createCustomer(Customer customer) {

		ICustomerDao customerDao=new customerDaoImpl();
		 customerDao.createCustomer(customer);
	}

	@Override
	public Set<Customer> getAllCustomer() {

		ICustomerDao customerDao=new customerDaoImpl();
		return customerDao.getAllCustomer();
	}

	@Override
	public Set<Address> getAllAddress() {
		ICustomerDao customerDao=new customerDaoImpl();
		return customerDao.getAllAddress();
	}

	@Override
	public Account createAccount(Account account) {

		ICustomerDao customerDao=new customerDaoImpl();
		return customerDao.createAccount( account);
	}

	@Override
	public List<Account> getAccountDetails(int customerId) {
		ICustomerDao customerDao=new customerDaoImpl();
		
		return customerDao.getAccountDetails(customerId);
	}

	@Override
	public void deposit(double amount,Transaction transaction,int customerId) {

		ICustomerDao customerDao=new customerDaoImpl();
		
		 customerDao.deposit(amount, transaction, customerId);
		
	}

	@Override
	public List<Transaction> getTransactionDetails() {
		ICustomerDao customerDao=new customerDaoImpl();
		
		 return customerDao.getTransactionDetails();
	}

	@Override
	public void withdraw(double amount, Transaction transaction,int customerId) {
		ICustomerDao customerDao=new customerDaoImpl();
		
		 customerDao.withdraw(amount, transaction,customerId);
		
	}

	@Override
	public void fundTransfer(double amount, Transaction transaction,int customerId) {
		ICustomerDao customerDao=new customerDaoImpl();
		
		 customerDao.fundTransfer(amount, transaction,customerId);
		
	}
	

}
