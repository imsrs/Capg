package createdifferentaccount;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	@Given("^Customer Details$")
	public void customer_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
	}

	@When("^For valid customer with minimum opening balance (\\d+)$")
	public void for_valid_customer_with_minimum_opening_balance(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^create new saving account$")
	public void create_new_saving_account() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  
	}

	@Then("^create new current account$")
	public void create_new_current_account() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^create new rd account$")
	public void create_new_rd_account() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^create new fd account$")
	public void create_new_fd_account() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}
	}


