
function validate(){
	//var uname=document.forms["frm"]["username"].value;
	//var password=document.forms["frm"]["pwd"].value;
	var uname=document.frm.username.value;
	var password=document.frm.pwd.value;
	if(uname ==""){
		alert("please fill the username");
		return false;
	}
	if(password ==""){
		alert("please eneter password");
		return false;
	}
}