package org.cap.dao;

import java.util.List;

import org.cap.model.Pilot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("pilotDbDao")
@Transactional
public interface IPilotDBDao extends JpaRepository<Pilot,Integer> {

	@Query("from Pilot p where p.salary>:salary")
	public List<Pilot> findSalary(Double salary); 
	
	
}
