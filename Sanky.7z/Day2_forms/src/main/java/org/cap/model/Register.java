package org.cap.model;

import java.time.LocalDate;
import java.util.Date;

import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

public class Register {

	@NotEmpty(message="Please enter FirstName+")
	private String firstName;
	private String lastName;
	private String address;
	private String city;
	private String gender;
	private String qualification;
	@DateTimeFormat(pattern="dd-MMM-YYYY")
	@Past(message="please enter a valid date")
	private Date dateOfBirth;
	@Length(min=3,max=9,message="password should be minimum 3 letters")
	private String password;
	private String confirmPassword;
	
	public Register() {
		
	}
	
	public Register(String firstName, String lastName, String address, String city, String gender, String qualification,
			Date dateOfBirth, String password, String confirmPassword) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.city = city;
		this.gender = gender;
		this.qualification = qualification;
		this.dateOfBirth = dateOfBirth;
		this.password = password;
		this.confirmPassword = confirmPassword;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	@Override
	public String toString() {
		return "Register [firstName=" + firstName + ", lastName=" + lastName + ", address=" + address + ", city=" + city
				+ ", gender=" + gender + ", qualification=" + qualification + ", dateOfBirth=" + dateOfBirth
				+ ", password=" + password + ", confirmPassword=" + confirmPassword + "]";
	}
	
	
	
	
	
}
