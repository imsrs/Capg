package org.cap.config;

import org.cap.model.Address;
import org.cap.model.Employee;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class JavaConfig {
	@Bean
	@Scope
	public Employee getEmployeeBean() {
		return new Employee(1001,"Tom",5000);
	}
@Bean("address")
public Address getAddressBean() {
	return new Address("Mumbai","Pune");
}
}
