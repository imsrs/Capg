package org.cap.boot;

import org.cap.config.JavaConfig;
import org.cap.model.Employee;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	public static void main(String[] args) {

AbstractApplicationContext con=new AnnotationConfigApplicationContext(JavaConfig.class);

Employee emp=con.getBean(Employee.class);
System.out.println(emp);
con.close();

	}

}
